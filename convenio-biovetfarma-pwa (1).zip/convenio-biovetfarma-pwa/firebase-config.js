// Firebase configuration placeholder.
// Replace the following values with your Firebase project's configuration.
// You can obtain these in the Firebase console → Project settings → General.

window.FIREBASE_CFG = {
  apiKey: "REPLACE_ME_API_KEY",
  authDomain: "REPLACE_ME_AUTH_DOMAIN",
  projectId: "REPLACE_ME_PROJECT_ID",
};

// Base URL for the Google Apps Script Web App backend.
// Example: "https://script.google.com/macros/s/AKfycb.../exec"
window.BASE_API_URL = "REPLACE_ME_BACKEND_URL";