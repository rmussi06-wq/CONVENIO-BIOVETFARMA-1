# Convênio Biovetfarma PWA

Este repositório contém uma aplicação web progressiva (PWA) básica para o projeto **Convênio Biovetfarma**. O front‑end é implementado com HTML, CSS e JavaScript simples, e utiliza os serviços do Firebase (Auth + Firestore) e um back‑end implementado em Google Apps Script.

## Estrutura do projeto

```
/
├── index.html              # Página principal com formulários de login e anotações
├── styles.css              # Estilos básicos da aplicação
├── app.js                  # Lógica principal (login, logout, notas, interação com o backend)
├── firebase-config.js      # Configurações do Firebase (substitua por suas credenciais)
├── manifest.webmanifest    # Manifesto PWA com definições e ícones
├── service-worker.js       # Service Worker para cache offline
├── assets/
│   └── icons/
│       ├── icon-192.png    # Ícone 192x192 (PWA)
│       └── icon-512.png    # Ícone 512x512 (PWA)
└── README.md               # Este arquivo
```

## Configuração do Firebase

1. Crie um projeto no [Firebase Console](https://console.firebase.google.com/) e ative **Authentication → Email/Password**.
2. Crie um **App Web** no Firebase para obter `apiKey`, `authDomain` e `projectId`.
3. Ative **Cloud Firestore** no modo Production e aplique as seguintes regras (garantem que cada usuário acesse apenas seus próprios documentos):

   ```
   rules_version = '2';
   service cloud.firestore {
     match /databases/{database}/documents {
       match /users/{uid}/{doc=**} {
         allow read, write: if request.auth != null && request.auth.uid == uid;
       }
       match /public/{doc=**} {
         allow read: if true;
         allow write: if false;
       }
     }
   }
   ```
4. Substitua os valores em `firebase-config.js`:

   ```js
   window.FIREBASE_CFG = {
     apiKey: "SUA_API_KEY",
     authDomain: "SEU_PROJETO.firebaseapp.com",
     projectId: "SEU_PROJECT_ID",
   };
   // URL do Web App do Apps Script (backend)
   window.BASE_API_URL = "https://script.google.com/macros/s/SEU_DEPLOY_ID/exec";
   ```

## Backend no Google Apps Script

O backend é hospedado como um **Web App** no Google Apps Script e responde a `GET /healthz` e `POST /api/v1/ping`. O código (exemplo em `backend/Code.gs`) inclui validação do **Firebase ID Token** usando as chaves públicas do Firebase e CORS restrito ao domínio do GitHub Pages.

### Passos resumidos

1. Abra [Google Apps Script](https://script.google.com/) e crie um novo projeto.
2. Defina o arquivo **appsscript.json** conforme:
   ```json
   {
     "timeZone": "America/Sao_Paulo",
     "exceptionLogging": "STACKDRIVER",
     "runtimeVersion": "V8"
   }
   ```
3. No arquivo **Code.gs**, copie o código fornecido no relatório. Ajuste `ALLOWED_ORIGIN` para o seu domínio do GitHub Pages e `FIREBASE_PROJECT_ID` para o ID do projeto Firebase.
4. Publique o script como **Web App** (Executar como: sua conta; Quem tem acesso: Anyone). Copie a URL pública e atribua à variável `BASE_API_URL` do `firebase-config.js`.

## Deploy no GitHub Pages

1. Crie um repositório público chamado `convenio-biovetfarma-pwa` (ou similar caso já exista) na sua conta GitHub.
2. Faça upload de todos os arquivos deste projeto para a branch `main`.
3. No repositório, acesse **Settings → Pages** e selecione:
   - **Source**: `main` branch
   - **Folder**: `/` (root)
4. Aguarde alguns minutos para a propagação. A URL gerada será algo como `https://SEU_USUARIO.github.io/convenio-biovetfarma-pwa/`.

**Importante:** adicione o domínio exato do Pages na constante `ALLOWED_ORIGIN` do seu backend para que o CORS funcione corretamente.

## Como usar

1. Acesse a URL do GitHub Pages.
2. Realize o login com email e senha cadastrados no Firebase.
3. Adicione anotações – elas serão armazenadas na coleção `users/{uid}/notes` no Firestore.
4. A aplicação funciona offline (cache de assets via Service Worker) e pode ser instalada como PWA nos navegadores compatíveis.

## Considerações

* **Segurança:** nunca comite chaves ou tokens sensíveis no repositório. Mantenha `firebase-config.js` com placeholders no Git e substitua localmente durante o deploy.
* **CORS:** o backend valida a origem da requisição. Atualize `ALLOWED_ORIGIN` sempre que mudar o domínio do frontend.
* **Rollback:** para desfazer a publicação, basta desativar o GitHub Pages ou remover o deploy do Apps Script. As regras do Firestore protegem os dados caso algo não funcione.