// Initialize Firebase using the global configuration defined in firebase-config.js
const appFB = firebase.initializeApp(window.FIREBASE_CFG);
const auth = firebase.getAuth(appFB);
const db = firebase.getFirestore(appFB);

// UI elements
const badge = document.getElementById('userBadge');
const formLogin = document.getElementById('formLogin');
const formNote = document.getElementById('formNote');
const listNotes = document.getElementById('listNotes');
const btnLogout = document.getElementById('btnLogout');
const loginSection = document.getElementById('loginSection');
const notesSection = document.getElementById('notesSection');

// Login form submission
formLogin.addEventListener('submit', async (e) => {
  e.preventDefault();
  const email = e.target.email.value.trim();
  const password = e.target.password.value.trim();
  try {
    await firebase.signInWithEmailAndPassword(auth, email, password);
    e.target.reset();
  } catch (err) {
    alert(err.message || 'Falha no login');
  }
});

// Logout button
btnLogout.addEventListener('click', () => {
  firebase.signOut(auth);
});

// Authentication state listener
firebase.onAuthStateChanged(auth, async (user) => {
  if (user) {
    // User is logged in
    badge.textContent = user.email;
    btnLogout.style.display = 'block';
    loginSection.style.display = 'none';
    notesSection.style.display = 'block';

    // Ping backend with idToken
    try {
      const idToken = await user.getIdToken();
      const res = await fetch(`${window.BASE_API_URL}?path=api/v1/ping`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ idToken }),
      });
      const data = await res.json();
      console.log('Ping backend:', data);
    } catch (err) {
      console.error('Erro ao pingar backend:', err);
    }

    // Firestore listener for notes
    const notesRef = firebase.collection(db, `users/${user.uid}/notes`);
    firebase.onSnapshot(notesRef, (snap) => {
      listNotes.innerHTML = '';
      snap.forEach((doc) => {
        const li = document.createElement('li');
        const d = doc.data();
        li.textContent = `[${new Date(d.createdAt).toLocaleString()}] ${d.text}`;
        listNotes.appendChild(li);
      });
    });

    // Note creation form
    formNote.addEventListener('submit', async (e) => {
      e.preventDefault();
      const text = e.target.note.value.trim();
      if (!text) return;
      try {
        await firebase.addDoc(notesRef, {
          text,
          createdAt: Date.now(),
          uid: user.uid,
        });
        e.target.reset();
      } catch (err) {
        console.error('Erro ao adicionar nota:', err);
      }
    });
  } else {
    // User is logged out
    badge.textContent = 'Deslogado';
    btnLogout.style.display = 'none';
    loginSection.style.display = 'block';
    notesSection.style.display = 'none';
    listNotes.innerHTML = '';
  }
});